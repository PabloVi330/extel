<?php
require '../websocket-server.php'; // Incluye el archivo del servidor WebSocket

// Crea una instancia de MyApp
$myApp = new MyApp();
?>