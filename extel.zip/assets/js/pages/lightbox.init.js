/*
Template Name: Minia - Admin & Dashboard Template
Author: Themesbrand
Website: https://themesbrand.com/
Contact: themesbrand@gmail.com
File: lightbox Js File
*/

// GLightbox Popup

var lightbox = GLightbox({
    selector: '.image-popup',
    title: false,
});


// GLightbox Popup

var lightboxDesc = GLightbox({
    selector: '.image-popup-desc',
});

// GLightbox Popup

var lightboxvideo = GLightbox({
    selector: '.image-popup-video-map',
    title: false,
});
